package ru.visualclient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
public class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("visual-client.json");
    public int theme = 3;
    public boolean wings = true, aura = true, particles = true, hud = true;
    public float wingSize = 1.0F;
    public static ClientConfig load() {
        try { if (Files.exists(FILE)) { ClientConfig c = GSON.fromJson(new String(Files.readAllBytes(FILE), StandardCharsets.UTF_8), ClientConfig.class); if (c != null) return c; } }
        catch (Exception ignored) { }
        return new ClientConfig();
    }
    public void save() {
        try { Files.createDirectories(FILE.getParent()); Files.write(FILE, GSON.toJson(this).getBytes(StandardCharsets.UTF_8)); }
        catch (IOException e) { VisualClient.LOGGER.error("Could not save config", e); }
    }
}
