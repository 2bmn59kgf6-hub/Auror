package ru.visualclient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import org.lwjgl.glfw.GLFW;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
public class VisualClient implements ClientModInitializer {
    public static final Logger LOGGER = LogManager.getLogger("VisualClient");
    public static ClientConfig CONFIG;
    private static boolean shiftWasDown;
    private static int particleTick;
    @Override public void onInitializeClient() {
        CONFIG = ClientConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean down = client.getWindow() != null && GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !shiftWasDown && client.currentScreen == null) client.openScreen(new VisualScreen());
            shiftWasDown = down;
            tickVisuals(client);
        });
        LOGGER.info("Aurora Visuals 1.16.5 loaded. Right Shift opens settings.");
    }
    private static void tickVisuals(MinecraftClient client) {
        if (client.player == null || client.world == null || !CONFIG.wings || !CONFIG.particles || (++particleTick % 3 != 0)) return;
        double yaw = Math.toRadians(client.player.yaw), bx = Math.sin(yaw) * 0.38, bz = -Math.cos(yaw) * 0.38;
        double scale = Math.max(0.5, Math.min(2.0, CONFIG.wingSize));
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 5; i++) {
                double t = i / 4.0, spread = (0.25 + t * 0.55) * scale, rise = (0.55 - t * 0.62) * scale;
                double x = client.player.getX() + bx + Math.cos(yaw) * side * spread;
                double z = client.player.getZ() + bz + Math.sin(yaw) * side * spread;
                client.world.addParticle(ParticleTypes.END_ROD, x, client.player.getY() + 1.15 + rise, z, 0.0, 0.008, 0.0);
            }
            if (CONFIG.aura) {
                double x = client.player.getX() + bx + (Math.random() - 0.5) * 1.5 * scale;
                double y = client.player.getY() + 1.0 + (Math.random() - 0.5) * 1.2 * scale;
                double z = client.player.getZ() + bz + (Math.random() - 0.5) * 0.5;
                client.world.addParticle(ParticleTypes.PORTAL, x, y, z, 0.0, 0.015, 0.0);
            }
        }
    }
}
