package ru.visualclient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
public class VisualScreen extends Screen {
    private static final String[] THEMES = {"Обычная", "Ч/Б", "Розовая", "Фиолетовая", "Красная"};
    public VisualScreen() { super(new LiteralText("AURORA VISUALS")); }
    @Override protected void init() {
        int c = width / 2, y = Math.max(35, height / 2 - 95);
        addButton(new ButtonWidget(c-105,y,210,20,themeLabel(),b->{VisualClient.CONFIG.theme=(VisualClient.CONFIG.theme+1)%THEMES.length;b.setMessage(themeLabel());VisualClient.CONFIG.save();})); y+=26;
        addButton(new ButtonWidget(c-105,y,210,20,wingsLabel(),b->{VisualClient.CONFIG.wings=!VisualClient.CONFIG.wings;b.setMessage(wingsLabel());VisualClient.CONFIG.save();})); y+=26;
        addButton(new ButtonWidget(c-105,y,210,20,auraLabel(),b->{VisualClient.CONFIG.aura=!VisualClient.CONFIG.aura;b.setMessage(auraLabel());VisualClient.CONFIG.save();})); y+=26;
        addButton(new ButtonWidget(c-105,y,210,20,sizeLabel(),b->{VisualClient.CONFIG.wingSize+=0.25F;if(VisualClient.CONFIG.wingSize>2.0F)VisualClient.CONFIG.wingSize=0.5F;b.setMessage(sizeLabel());VisualClient.CONFIG.save();})); y+=26;
        addButton(new ButtonWidget(c-105,y,210,20,particlesLabel(),b->{VisualClient.CONFIG.particles=!VisualClient.CONFIG.particles;b.setMessage(particlesLabel());VisualClient.CONFIG.save();})); y+=26;
        addButton(new ButtonWidget(c-105,y,210,20,new LiteralText("Готово"),b->onClose()));
    }
    private LiteralText themeLabel(){return new LiteralText("Тема: "+THEMES[Math.max(0,Math.min(THEMES.length-1,VisualClient.CONFIG.theme))]);}
    private LiteralText wingsLabel(){return new LiteralText("Крылья: "+(VisualClient.CONFIG.wings?"ВКЛ":"ВЫКЛ"));}
    private LiteralText auraLabel(){return new LiteralText("Аура: "+(VisualClient.CONFIG.aura?"ВКЛ":"ВЫКЛ"));}
    private LiteralText particlesLabel(){return new LiteralText("Частицы: "+(VisualClient.CONFIG.particles?"ВКЛ":"ВЫКЛ"));}
    private LiteralText sizeLabel(){return new LiteralText("Размер крыльев: "+String.format(java.util.Locale.ROOT,"%.2f",VisualClient.CONFIG.wingSize));}
    @Override public void render(MatrixStack m,int mx,int my,float delta){renderBackground(m);int color=themeColor();fill(m,0,0,width,height,0xD9101020);fill(m,width/2-120,height/2-112,width/2+120,height/2+105,0xE6222038);fill(m,width/2-120,height/2-112,width/2+120,height/2-109,color);drawCenteredText(m,textRenderer,title,width/2,height/2-104,0xFFFFFF);super.render(m,mx,my,delta);drawCenteredText(m,textRenderer,new LiteralText("Right Shift — открыть меню"),width/2,height-16,0xAAAAAA);}
    private int themeColor(){switch(VisualClient.CONFIG.theme){case 1:return 0xFFDDDDDD;case 2:return 0xFFFF69B4;case 4:return 0xFFFF3333;default:return 0xFF9B6BFF;}}
    @Override public void onClose(){VisualClient.CONFIG.save();super.onClose();}
}
